import click

from . import GitlabClient
from .gitlab_group import gitlab


@gitlab.command
@click.option('--group')
@click.argument('file', type=click.File('r'))
@click.pass_obj
def add_file(client: GitlabClient, group, file):
    contents = file.read()

    print(file.name)
    print(file.extension)

    projects = client.get_projects(group)
